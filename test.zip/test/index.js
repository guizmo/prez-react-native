var lodash = require('lodash');

const prepaidSize = 5;

// diff equal = ticket = prepaid | perfect
// diff positive = prepaid > ticket | client must loose the less possible | 10 better than 20
// diff negatif = ticket > prepaid | client must pay the less possible | -10 better than -20



let list = [{ "diff": 100, "line": { "id": 1 } }, { "diff": 30, "line": { "id": 2 } }, { "diff": 20, "line": { "id": 5 } }, { "diff": 50, "line": { "id": 3 } }, { "diff": 0, "line": { "id": 4 } }, { "diff": -250, "line": { "id": 5 } }, { "diff": 0, "line": { "id": 6 } }, { "diff": -10, "line": { "id": 5 } }, { "diff": 25, "line": { "id": 5 } }, { "diff": -5, "line": { "id": 7 } }, { "diff": -300, "line": { "id": 8 } }];

const equal = list.filter(l => l.diff === 0);
let positif = list.filter(l => l.diff > 0);
let negatif = list.filter(l => l.diff < 0);

positif = lodash.orderBy(positif, ['diff'], ['asc']);
negatif = lodash.orderBy(negatif, ['diff'], ['desc']);

console.group("ALL SIZES");
console.log('equal', equal.length);
console.log('positif', positif.length);
console.log('negatif', negatif.length);
let bestShows = [].concat(equal, positif, negatif);
console.log('bestShows', bestShows);
console.groupEnd();

console.group("SLICED");
console.log('bestShows', bestShows.slice(0, prepaidSize));
console.groupEnd();

bestShows = lodash.uniqBy(bestShows, 'line.id');
console.group("UNIQ");
console.log('bestShows', bestShows);
console.groupEnd();

console.group("UNIQ SLICED");
console.log('bestShows', bestShows.slice(0, prepaidSize));
console.groupEnd();
